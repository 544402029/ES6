(function(window,document){
    //通用方法  
    const method = {
        //添加子元素
        appendChild(parent, ...children) {
        children.forEach(el => {
            parent.appendChild(el);
           
        });
        },
        //查找元素
        $(selector, root = document) {
        return root.querySelector(selector);
        },
        $$(selector, root = document) {
        return root.querySelectorAll(selector);
        }
    };


    //构造函数
    const Dropdown=function(options){
        this._init(options);//初始化
        this._createEles();//添加DOM解构
        this._bind();//绑定事件
    }

    //初始化
    Dropdown.prototype._init=function({searchBoxWrap}){
        this.types=[];//全部类型
        this.selectOption={};//根据分类得到元素下标
        this.optionsText=[];//所有原生dom元素的内容文字
        this.optionsLisEle=[];//按照类型进行分类
        this.dropdownBox=null;//下拉框
        this.searchBox=null;//搜索框
        this.searchBoxWrap=searchBoxWrap;//搜索框盒子

        this.classify(method.$$('.original_option_item'));//获取每个原生dom元素作为分类函数的参数
    }
    

    //分类
    Dropdown.prototype.classify=function(data){
        data.forEach(ele=>{//对所有的原生dom进行遍历
            let type=ele.getAttribute('type');//获取了每个元素类型
            if(!this.types.includes(type)){//检测全部类型里是否有这个类型,如果没有的话添加到全部类型内
                this.types.push(type);
            };
            
            if(!Object.keys(this.selectOption).includes(type)){//检测这个分类中是否有此分类,没有成为空数组
                this.selectOption[type]=[];
            }//老师,这里如果用else少了两个元素进去,是什么原因?是因为如果else就不建立数组?????
           if(Object.keys(this.selectOption).includes(type)) {//检测这个分类中是否有此分类,
                this.selectOption[type].push(parseInt(ele.value));//有的话将value值传入相应的分类数组
            };//当前分组:   构建工具:[1,2,3]    前端框架:[4,5,6,7]
            //console.log(this.selectOption[type])
            this.optionsText.push(ele.innerText)//将所有dom元素文字推入一个数组
        });
    };
    
    //生成DOM元素
    Dropdown.prototype._createEles=function(){
        let dropdown_box=document.createElement('div');
        dropdown_box.className='dropdown_box';
        method.appendChild(method.$('.select_box'),dropdown_box);
        this.dropdownBox=method.$('.dropdown_box');
        if(this.searchBoxWrap){
            method.appendChild(this.dropdownBox,this._createSearchBox());//向下拉框添加了搜索框盒子
        }

        let dropdown_box_list=document.createElement('div');
        dropdown_box_list.className='dropdown_box_list';

        for(let optionHeader in this.selectOption){
            let dropdownBoxListOption=document.createElement('div');
            let option_header=document.createElement('div');
            let optionList=document.createElement('div');
            dropdownBoxListOption.className='dropdown_box_list_option';
            optionList.className='option_list';
            option_header.className='option_header';
            option_header.innerText=optionHeader;//把循环到的键名(类型名)分别赋值给分类表头标签
            for(let optionItem of this.selectOption[optionHeader]){
                optionList.innerHTML+=`<div value="${optionItem}" type="${optionHeader}" class="option_item">${this.optionsText[optionItem-1]}</div>`;
                //创建列表,把每一个原生dom按分类放入列表   optionItem循环实际是类型数组里的值,也就是value值   optionheader是刚获取的键名   由于dom文字数组按0开始的,value是1开始,所以减1
               // console.log(optionItem)
            }
            method.appendChild(dropdownBoxListOption,option_header,optionList);//把标题和列表传入相应类型分组
           
            this.optionsLisEle.push(dropdownBoxListOption);//推入类型数组
            method.appendChild(dropdown_box_list,dropdownBoxListOption);//放入列表框
        }


        method.appendChild(this.dropdownBox,dropdown_box_list)//把列表框放入下拉框
        this.searchBox = method.$('.search_box');//搜索框
    }


    //搜索框盒子
    Dropdown.prototype._createSearchBox=function(){
        let searchBoxWrap=document.createElement('div');
        searchBoxWrap.className='search_box_wrap';
        searchBoxWrap.innerHTML='<input type="text" name="search" placeholder="搜索" autocomplete="off" class="search_box">'
        return searchBoxWrap;
    }

    //显示
    Dropdown.prototype._show=function(){
        this.dropdownBox.style.transform='translate(0,0)';
        this.dropdownBox.style.height="200px";
        this.dropdownBox.style.opacity="1";
    }
    //隐藏
    Dropdown.prototype._hide=function(){
        this.dropdownBox.style.transform='translate(0,50)';
        this.dropdownBox.style.height='0';
        this.dropdownBox.style.opacity='0';
    }

    //绑定事件
    Dropdown.prototype._bind=function(){
        //点击选择框显示下拉框
        method.$('.select_box').addEventListener('click',(e)=>{
            e.stopPropagation();//禁止冒泡
            this._show();
        })
        //点击文档处隐藏下拉框
        document.addEventListener('click',()=>{
            this._hide();
        })
        //输入相应文字显示相应列表
        this.searchBox.addEventListener('input', () => {
            let regExp=new RegExp(`${this.searchBox.value}`,'ig');//检测搜索框输入的值
            let foundEle=[];
            Object.values(this.selectOption).forEach((optionHeader,index1)=>{
             
                this.optionsText.forEach((optionsText,index2)=>{
                    if(regExp.test(optionsText)){//匹配输入值和列表内的值
                        //console.log(optionsText)
                        //列表内的值和输入值相同先赋值给一个变量,findIndex获取的是下标
                        let textValue=this.optionsText.findIndex(idx=>idx===optionsText);
                        method.$$('.option_list')[index1].innerHTML='';//有一样就清除其他的列表内容
                        //console.log(optionHeader)
                        if(optionHeader.includes(textValue+1)){//检测列表内是否有相同的下标,(optionheader是value的值,此处相同索引下标得+1)
                            foundEle.push(`<div value="${textValue+1}" type="${this.types[index1]}" class="option_item">${this.optionsText[index2]}</div>`);
                           // console.log(foundEle)
                        }
                    }
                })
                method.$$('.option_list')[index1].innerHTML=foundEle.join('');//把数组加入到dom结构中
                foundEle=[];//加入之后重新变成空数组
            })
        })

        let value;
        method.$$('.dropdown_box').forEach((ele=>{//循环下拉框
            ele.addEventListener('click',(e)=>{
                if(e.target.className!=='option_item') return;//如果点击的元素不是列表,什么都不做
                e.stopPropagation();
                e.target.style.backgroundColor='#4996f9';//改变点击列表背景颜色
                this._hide();//点击列表后隐藏下拉框
                setTimeout(()=>{
                    e.target.style.backgroundColor='#ffffff';
                    //点击之后列表重新变成白色背景
                },300);

                //显示改变的文字
                value=e.target.getAttribute('value');
                method.$('#output').innerHTML=`之前的值是${method.$('.select_box_text').innerText}-${value}<br/>
                改变后的值是${e.target.innerText}-${e.target.getAttribute('value')}`;
                method.$('.select_box_text').innerText=e.target.innerText;
            })
        }))

    }
    window.$Dropdown=Dropdown;
}(window,document))